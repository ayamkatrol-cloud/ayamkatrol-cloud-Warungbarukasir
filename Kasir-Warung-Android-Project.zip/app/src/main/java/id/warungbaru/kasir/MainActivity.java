package id.warungbaru.kasir;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.*;
import android.bluetooth.*;
import android.content.pm.PackageManager;
import android.util.Base64;
import java.io.OutputStream;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private BluetoothSocket socket;
    private BluetoothDevice connected;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 91);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class PrinterBridge {
        @JavascriptInterface public String pairedDevices() {
            try {
                BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                if (a == null) return "[]";
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return "[]";
                StringBuilder s = new StringBuilder("["); boolean first = true;
                for (BluetoothDevice d : a.getBondedDevices()) {
                    if (!first) s.append(",");
                    first = false;
                    s.append("{\"name\":\"").append(esc(d.getName())).append("\",\"address\":\"").append(esc(d.getAddress())).append("\"}");
                }
                return s.append("]").toString();
            } catch(Exception e) { return "[]"; }
        }
        @JavascriptInterface public String connect(String address) {
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return "Izin Bluetooth belum diberikan";
                BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
                BluetoothDevice d = a.getRemoteDevice(address);
                if (socket != null) try { socket.close(); } catch(Exception ignored) {}
                socket = d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                a.cancelDiscovery(); socket.connect(); connected = d; return "OK";
            } catch(Exception e) { socket = null; connected = null; return "Gagal: " + e.getMessage(); }
        }
        @JavascriptInterface public String isConnected() { return socket != null && socket.isConnected() ? "true" : "false"; }
        @JavascriptInterface public void disconnect() {
            try { if(socket != null) socket.close(); } catch(Exception ignored) {}
            socket = null; connected = null;
        }
        @JavascriptInterface public String printBase64(String data) {
            try {
                if(socket == null || !socket.isConnected()) return "Printer belum terhubung";
                byte[] bytes = Base64.decode(data, Base64.DEFAULT);
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B,0x40});
                out.write(bytes); out.flush(); return "OK";
            } catch(Exception e) { return "Gagal mencetak: " + e.getMessage(); }
        }
    }
    private String esc(String s) { return s == null ? "" : s.replace("\\","\\\\").replace("\"","\\\""); }
    @Override public void onBackPressed() {
        if(web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
